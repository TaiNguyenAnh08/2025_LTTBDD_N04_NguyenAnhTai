class CategoriesModel {
  String? categoryName;
  String? imgUrl;
}
